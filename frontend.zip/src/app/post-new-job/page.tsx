import Main from "./main";

const PostNewJob = () => {
  return (
    <main className="flex justify-center items-center w-screen h-screen bg-gradient-to-r from-[#D8E5EE] to-[#EED4E9]">
      <Main />
    </main>
  );
};

export default PostNewJob;
